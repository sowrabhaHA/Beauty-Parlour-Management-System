<!--footer-->
    <div class="footer">
       <p>&copy; 2020
       BPMS Admin Panel.</p>
    </div>
        <!--//footer-->