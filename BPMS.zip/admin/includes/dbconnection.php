<?php
$con=mysqli_connect("localhost", "id12987205_root", "Chandaish", "id12987205_salon");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
